const recursive = require("recursive-readdir");
const path = require("path");
const fs = require("fs");

fs.readdir("./src", (err, groups) => {
  fs.writeFile(
    path.resolve("./src", "index.js"),
    `${groups
      .map(group => {
        if (group.slice(-3) === ".js") return false;
        if (group === "style") return false;
        return `import ${group} from "./${group}.js"`;
      })
      .filter(item => item)
      .join("\r\n")}

  export {
    ${groups
      .map(group => {
        if (group.slice(-3) === ".js") return false;
        if (group === "style") return false;
        return group;
      })
      .filter(item => item)
      .join(",\r\n")}
  }`,
    () => {
      console.log("Общий индекс записан");
    }
  );

  for (let key in groups) {
    const group = groups[key];
    if (group.slice(-3) === ".js") continue;
    if (group === "style") continue;

    console.log(`Индекс для группы ${group}`);

    recursive(path.resolve("./src", group), ["*.js"], function(
      err,
      componentsFiles
    ) {
      if (err) {
        console.error(err);
      } else {
        const imports = componentsFiles
          .map(file => {
            if (path.extname(file) !== ".jsx") return false;
            return `import ${path
              .basename(file)
              .replace(".jsx", "")} from "./${path
              .relative(path.resolve("./src", group), file)
              .replace(".jsx", "")}"`;
          })
          .filter(item => item)
          .join("\r\n");

        const exports = `export {
          ${componentsFiles
            .map(file => {
              if (path.extname(file) !== ".jsx") return false;
              return path.basename(file).replace(".jsx", "");
            })
            .filter(item => item)
            .join(",\r\n")}
}`;

        fs.writeFile(
          path.resolve("./src", group, "index.js"),
          `${imports}

${exports}`,
          () => {
            console.log("Записан");
          }
        );
      }
    });
  }
});
