import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import {{PascalCase name}} from "./{{PascalCase name}}";

const options = {
  info: {
    inline: false,
    text: `
    {{groupName}} - {{PascalCase name}}.

    Пока только выводит свое название.

    ~~~
    import { {{PascalCase name}} } from "heaven-components/dist/{{projectName}}";
    ~~~

    [Ссылка на дизайн](https://{{PascalCase name}}/)
    [Ссылка на Jira](https://{{PascalCase name}}/)

    Ключевые слова: {{keywords}}.
  `
  }
}

storiesOf("{{groupName}}|{{PascalCase name}}/{{projectNamePrefix}}", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["{{PascalCase name}}"] })

  .add(
    "Стандартный вид",
    () => <{{PascalCase name}} />,
    options
  )
