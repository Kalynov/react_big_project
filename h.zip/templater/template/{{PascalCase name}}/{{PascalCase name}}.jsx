import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.{{PascalCase name}} использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const Container = styled.div`
  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.{{PascalCase name}} }
`;

class {{PascalCase name}} extends React.PureComponent {
  static propTypes = {

  };

  static defaultProps = {

  };

  state = {};

  render() {
    return (
      <Container>
        I am {{PascalCase name}}!
      </Container>
    );
  }
}

export default {{PascalCase name}};
