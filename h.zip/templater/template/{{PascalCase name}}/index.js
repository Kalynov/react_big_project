import {{PascalCase name}} from "./{{PascalCase name}}"

export default {{PascalCase name}};
