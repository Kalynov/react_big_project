const path = require("path");
const fs = require("fs");
const inquirer = require("inquirer");

const recursive = require("recursive-readdir");
const Handlebars = require("handlebars");
const shell = require("shelljs");
const naming = require("naming");

Handlebars.registerHelper("camelCase", function(text) {
  return naming(text, "camel");
});

Handlebars.registerHelper("PascalCase", function(text) {
  return naming(text, "pascal");
});

Handlebars.registerHelper("snake-case", function(text) {
  return naming(text, "snake");
});

Handlebars.registerHelper("kebab_case", function(text) {
  return naming(text, "kebab");
});

Handlebars.registerHelper("CAPS", function(text) {
  return naming(text, "caps");
});

const templateFiles = path.resolve(__dirname, "template");

let projects = [],
  groups = [];
const sectionsIgnore = ["style"];
const srcDir = path.resolve("./", "src");

fs.readdir(srcDir, (err, files) => {
  files.forEach(file => {
    if (sectionsIgnore.includes(file)) return;
    fullPath = path.resolve(srcDir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      projects.push(file);
      const sectionGroups = fs.readdirSync(fullPath);
      groups.push(...sectionGroups.filter(group => !groups.includes(group)));
    }
  });

  inquirer
    .prompt([
      {
        type: "question",
        name: "name",
        message: "Введите название компонента",
        validate: answer => answer.length !== 0
      },

      {
        type: "list",
        name: "projectName",
        message: "Как называется проект?",
        choices: [...projects, "Добавить новый"]
      },
      {
        type: "question",
        name: "projectName",
        message: "Как называется проект?",
        when: answers => answers.projectName === "Добавить новый",
        validate: answer => answer.length !== 0
      },
      {
        type: "list",
        name: "groupName",
        message: "К какому проекту отнести компонент?",
        choices: [...groups, "Добавить новую"]
      },
      {
        type: "question",
        name: "groupName",
        message: "К какому проекту отнести компонент?",
        when: answers => answers.groupName === "Добавить новую",
        validate: answer => answer.length !== 0
      },
      {
        type: "question",
        name: "keywords",
        message: "Какие ключевые слова подходят компоненту (через запятую)?",
        validate: answer => answer.length !== 0
      }
    ])
    .then(answers => {
      const componentName = answers.name;

      answers.groupName = naming(answers.groupName, "pascal");

      const directionDir = `src/${answers.projectName}/${answers.groupName}`;

      // const topSection = {
      //   Простой: "Простые компоненты",
      //   Сложный: "Сложные компоненты"
      // }[answers.topSection];

      const params = {
        name: componentName,
        projectNamePrefix:
          answers.projectName
            .toString()
            .trim()
            .toLowerCase() !== "common"
            ? `[${answers.projectName}] `
            : "",
        projectName: answers.projectName,
        groupName: answers.groupName,
        keywords: answers.keywords
      };

      recursive(templateFiles, function(err, files) {
        if (err) {
          console.error(err);
        } else {
          const filesCount = files.length;
          let filesProcessed = 0;

          for (let key in files) {
            const file = files[key];
            const basename = path.basename(file);
            const relativeName = path.relative(templateFiles, file);

            fs.readFile(file, "utf8", function(err, contents) {
              if (err) {
                console.error(err);
                callback(err);
              } else {
                const newFileName = path.resolve(
                  directionDir,
                  Handlebars.compile(relativeName)(params)
                );

                shell.mkdir("-p", path.resolve(path.dirname(newFileName)));
                const fileContents = Handlebars.compile(contents)(params);

                fs.writeFile(path.resolve(newFileName), fileContents, function(
                  err
                ) {
                  filesProcessed++;
                  if (err) {
                    callback(err);
                    console.error(err);
                  }
                  if (filesProcessed === filesCount) {
                    console.log("Готово!");
                    console.log(`Компонент лежит в ${directionDir}`);
                    process.exit();
                  }
                });
              }
            });
          }
        }
      });
    })
    .catch(err => {
      console.error(err);
      process.exit(0);
    });
});
