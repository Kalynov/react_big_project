export default {
  globalStyle: `
    box-sizing: border-box;
  `,
  STS: {
    colors: {
      PrimaryColor: "#1f367d",
      BorderColor: "#d0dfe8",

      info: "#dbdee5",
      warning: "#FBDC95",
      success: "#93D083",
      danger: "#ED7B7D"
    },
    margins: {
      default: "30px"
    }
  },
  chartsColors: ["#78CE90", "#B978CE", "#FFC76F", "#FFC76F"]
};
