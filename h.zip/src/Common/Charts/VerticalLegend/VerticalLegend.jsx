import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.VerticalLegend использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const Container = styled.div`
  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend}
`;

const Line = styled.div`
  display: block;
  margin-bottom: 20px;
  &:last-child {
    margin-bottom: 0;
  }
  padding-left: 17px;
  position: relative;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend__Line}
`;

const Icon = styled.div`
  height: 9px;
  width: 9px;
  border-radius: 9px;
  background-color: ${props => {
    const colors = props.theme.chartsColors;
    return colors[props.order];
  }};
  position: absolute;
  left: 0;
  top: 3px;
  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend__Icon};
`;

const Title = styled.div`
  color: #888e9f;
  font-family: "ProximaNova-Regular";
  font-size: 14px;
  line-height: 17px;
  margin-bottom: 4px;
  white-space: wrap;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend__Title}
`;

const Value = styled.div`
  color: #000000;
  font-family: "ProximaNova-Regular";
  font-size: 14px;
  line-height: 17px;
  white-space: nowrap;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend__Value}
`;

const BoldValue = styled.span`
  font-weight: bold;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend__Value}
`;
class VerticalLegend extends React.PureComponent {
  static propTypes = {
    data: PropTypes.shape({
      names: PropTypes.oneOfType([PropTypes.object, PropTypes.array]),
      values: PropTypes.oneOfType([PropTypes.object, PropTypes.array])
    }).isRequired
  };

  static defaultProps = {};

  state = {};

  render() {
    const sum = Object.values(this.props.data.values).reduce(
      (acc, item) =>
        parseFloat(
          acc
            .toString()
            .split(" ")
            .join("")
        ) +
        parseFloat(
          item
            .toString()
            .split(" ")
            .join("")
        )
    );
    return (
      <Container>
        {Object.keys(this.props.data.values).map((key, numKey) => {
          const value = this.props.data.values[key];
          const numValue = parseFloat(
            value
              .toString()
              .split(" ")
              .join("")
          );
          return (
            value != 0 && (
              <Line key={key}>
                <Icon order={numKey} />
                <Title>
                  {this.props.data.names[key]}
                  {sum != 0 && " – "} <BoldValue> {value} </BoldValue>{" "}
                  {" (" + ((100 * numValue) / sum).toFixed(1) + "%)"}
                </Title>
              </Line>
            )
          );
        })}
      </Container>
    );
  }
}

export default VerticalLegend;
