import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import VerticalLegend from "./VerticalLegend";

const options = {
  info: {
    inline: false,
    text: `
    Charts - VerticalLegend.

    Выводит вертикальную легенду для графиков

    ~~~
    import { VerticalLegend } from "heaven-components/dist/Common";
    ~~~

    [Ссылка на дизайн](https://projects.invisionapp.com/d/main#/console/13027675/307260491/preview)
    [Ссылка на Jira](https://jira-new.skytracking.ru/browse/STS-355)

    Ключевые слова: график, легенда, информация, статистика, аналитика, отчет.
  `
  }
};

storiesOf("Charts|VerticalLegend", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["VerticalLegend"] })

  .add(
    "Стандартный вид",
    () => (
      <VerticalLegend
        data={{
          names: {
            typeOne: "Название 1",
            typeTwo: "Название 2",
            typeThree: "Название 3"
          },
          values: {
            typeOne: 10,
            typeTwo: 20,
            typeThree: 30
          }
        }}
      />
    ),
    options
  )
  .add(
    "Нулевые значения вид",
    () => (
      <VerticalLegend
        data={{
          names: {
            typeOne: "Название 1",
            typeTwo: "Название 2",
            typeThree: "Название 3"
          },
          values: {
            typeOne: 0,
            typeTwo: 0,
            typeThree: 0
          }
        }}
      />
    ),
    options
  );
