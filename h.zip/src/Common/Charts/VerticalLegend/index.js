import VerticalLegend from "./VerticalLegend";

export default VerticalLegend;
