import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import BaseChart from "./BaseChart";
import styled from "styled-components";

const PageBackground = styled.div`
  background: gray;
  padding: 100px;
`;

const RelativeParent = styled.div`
  position: relative;
  width: 600px;
  height: 400px;

  & > div,
  & > div > div {
    position: absolute;
    height: 100%;
    width: 100%;
  }
`;

const options = {
  info: {
    inline: false,
    text: `
    Charts - BaseChart.

    Включает основные параметры для графиков, монтирует график и легенду.
    Растягивается на всю ширину и высоту, абсолютно позиционирован.

    В примерах здесь помещен в блок 600 на 400 пикселей, который находится в блоке с серым фоном.

    [Документация по параметрам графиков](https://www.chartjs.org/docs/latest)

    ~~~
    import { BaseChart } from "heaven-components/dist/Common";
    ~~~

    [Ссылка на дизайн](https://projects.invisionapp.com/d/main#/console/13027675/307260491/preview)
    [Ссылка на Jira](https://jira-new.skytracking.ru/browse/STS-355)

    Ключевые слова: график, диаграмма, аналитика, статистика, отчет.
  `
  }
};

const legendData = {
  names: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
  values: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
};

const chartData = {
  labels: ["Название 1", "Название 2", "Название 3"],
  datasets: [
    {
      data: [300, 50, 100]
    }
  ]
};

storiesOf("Charts|BaseChart", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["BaseChart"] })
  .addDecorator(story => (
    <PageBackground>
      <RelativeParent>{story()}</RelativeParent>
    </PageBackground>
  ))

  .add(
    "Стандартный вид",
    () => (
      <BaseChart
        title="Заголовок"
        chartData={chartData}
        legendData={legendData}
      />
    ),
    options
  )

  .add(
    "С перекрытием цветов",
    () => (
      <BaseChart
        title="Заголовок"
        chartData={chartData}
        legendData={legendData}
        forceColors={["black", "green", "blue"]}
      />
    ),
    options
  )

  .add(
    "В обратном порядке",
    () => (
      <BaseChart
        title="Заголовок"
        chartData={chartData}
        legendData={legendData}
        legendPosition="before"
      />
    ),
    options
  )

  .add(
    "Вертикальный",
    () => (
      <BaseChart
        title="Заголовок"
        chartPosition="vertical"
        legendBasis={7}
        chartData={chartData}
        legendData={legendData}
        chartType="Bar"
      />
    ),
    options
  )

  .add(
    "Вертикальный (линия)",
    () => (
      <BaseChart
        title="Заголовок"
        chartPosition="vertical"
        legendBasis={7}
        chartData={chartData}
        legendData={legendData}
        chartType="Line"
        chartOptions={{
          scales: {
            yAxes: [
              {
                ticks: {
                  beginAtZero: true
                }
              }
            ]
          }
        }}
        addBorderColor
        addBackgroundColor={false}
        addHoverColor={false}
      />
    ),
    options
  );
