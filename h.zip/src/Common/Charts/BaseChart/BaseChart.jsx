import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";
import Theme from "../../../theme";
import VerticalLegend from "../VerticalLegend";
import HorizontalLegend from "../HorizontalLegend";
import * as ReactChartJs from "react-chartjs-2";
import { ThemeProvider } from "styled-components";
import DefaultTheme from "../../../theme";

import { cloneDeep, merge } from "lodash";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.BaseChart использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const Container = styled.div`
  position: absolute;
  width: 100%;
  height: 100%;
  background: white;

  padding: 20px;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.BaseChart}
`;

const Title = styled.div`
  color: #000000;
  font-family: "ProximaNova-Regular";
  font-size: ${props => props.fs}pt;
  line-height: 20px;
  margin-bottom: 20px;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.BaseChart__Title}
`;

const Content = styled.div`
  width: 100%;
  padding-top: 20px;
  height: calc(100% - 60px);
  display: flex;
  flex-direction: ${props => props.direction};
  flex-wrap: nowrap;
  justify-content: center;
  align-content: stretch;
  align-items: center;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.BaseChart__Content}
`;

const ChartSide = styled.div`
  order: ${props => props.order};
  flex: 1 1 auto;

  flex-basis: ${props => props.basis}%;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.BaseChart__ChartSide}
`;

const LegendSide = styled.div`
  order: ${props => props.order};
  flex: 1 1 auto;

  max-height: 100%;
  overflow-x: hidden;
  overflow-y: auto;

  &::-webkit-scrollbar {
    width: 5px;
    border-radius: 15px;
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 15px;
    background-color: #2c4695;
  }

  &::-webkit-scrollbar-track {
    background-color: #f1f1f1;
  }

  flex-basis: ${props => props.basis}%;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.BaseChart__LegendSide}
`;

const Divider = styled.div`
  order: 1;
  height: 100%;
  width: 2px;
  border: 1px solid #e6e9f3;
  margin: 0 20px;
  flex: 0;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.BaseChart__Divider}
`;

const HorizontalDivider = styled.div`
  order: 1;
  width: 100%;
  min-height: 20px;
  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props =>
    props.theme.BaseChart__HorizontalDivider};
`;

const Div = styled.div``;

class BaseChart extends React.Component {
  static propTypes = {
    /** Заголовок блока */
    title: PropTypes.string.isRequired,
    /** Размер заголовка в pt */
    titleFontSize: PropTypes.number,
    /** Расположение графика и легенды */
    chartPosition: PropTypes.oneOf(["horizontal", "vertical"]),
    /** Легенда до графика или после */
    legendPosition: PropTypes.oneOf(["before", "after"]),
    /** Сколько процентов отводить под легенду по умолчанию */
    legendBasis: PropTypes.number,
    /** Функция, возвращающая кастомный график */
    customChart: PropTypes.oneOfType([PropTypes.func, PropTypes.bool]),
    /** Тип графика */
    chartType: PropTypes.oneOf([
      "Doughnut",
      "Pie",
      "Line",
      "Bar",
      "HorizontalBar",
      "Radar",
      "Polar"
    ]),
    /** Опции для графика */
    chartOptions: PropTypes.object,
    /** Данные для графика (Chart.js или кастомный) */
    chartData: PropTypes.object.isRequired,
    /** Данные для легенды */
    legendData: PropTypes.oneOfType([PropTypes.array, PropTypes.object])
      .isRequired,
    /** Скрыть легенду */
    hideLegend: PropTypes.bool,
    /** Добавить цвет границ */
    addBorderColor: PropTypes.bool,
    /** Добавить цвет фона */
    addBackgroundColor: PropTypes.bool,
    /** Добавить цвет при наведении */
    addHoverColor: PropTypes.bool,
    /** Цвета для графиков */
    forceColors: PropTypes.oneOfType([PropTypes.array, PropTypes.bool]),
    /** Функция при клике на график; Данные берутся из this.data.labels */
    onChartClick: PropTypes.func
  };

  static defaultProps = {
    titleFontSize: 17,
    chartPosition: "horizontal",
    legendPosition: "after",
    legendBasis: 50,
    customChart: false,
    chartType: "Pie",
    chartOptions: {},
    hideLegend: false,
    addBorderColor: false,
    addBackgroundColor: true,
    addHoverColor: true,
    forceColors: false,
    onChartClick: () => {}
  };

  state = {};

  componentDidUpdate(prevProps, prevState) {
    if (
      prevProps.chartPosition !== this.props.chartPosition ||
      prevProps.customChart !== this.props.customChart ||
      prevProps.chartType !== this.props.chartType ||
      prevProps.legendBasis !== this.props.legendBasis ||
      prevProps.hideLegend !== this.props.hideLegend ||
      prevProps.addBorderColor !== this.props.addBorderColor ||
      prevProps.addBackgroundColor !== this.props.addBackgroundColor ||
      prevProps.addHoverColor !== this.props.addHoverColor
    ) {
      this.contentRef = null;
      setTimeout(() => {
        this.forceUpdate();
      });
    }
  }

  render() {
    const ColorsTheme = this.props.forceColors
      ? {
          chartsColors: this.props.forceColors
        }
      : {};

    const chartsColors = this.props.forceColors || Theme.chartsColors;

    const onChartClick = { onClick: this.props.onChartClick };

    const Legend =
      this.props.chartPosition === "vertical"
        ? HorizontalLegend
        : VerticalLegend;

    const Chart = this.props.customChart
      ? this.props.customChart
      : ReactChartJs[this.props.chartType];

    const legendBasis = this.props.hideLegend ? 0 : this.props.legendBasis;

    let data = cloneDeep(this.props.chartData);

    data.datasets = data.datasets.map((dataset, datasetKey) => {
      let colorsData = {};

      if (this.props.addBorderColor) {
        colorsData.borderColor = chartsColors[datasetKey % chartsColors.length];
      }
      if (this.props.addBackgroundColor) {
        colorsData.backgroundColor = dataset.data.map((datasetData, key) => {
          return chartsColors[
            (datasetKey + (data.datasets.length > 1 ? 0 : key)) %
              chartsColors.length
          ];
        });
      }
      if (this.props.addHoverColor) {
        colorsData.hoverBackgroundColor = dataset.data.map(
          (datasetData, key) => {
            return chartsColors[
              (datasetKey + (data.datasets.length > 1 ? 0 : key)) %
                chartsColors.length
            ];
          }
        );
      }
      return merge(dataset, colorsData);
    });

    return (
      <ThemeProvider theme={merge(DefaultTheme, ColorsTheme)}>
        <Container>
          <Title fs={this.props.titleFontSize}>{this.props.title}</Title>
          <Content
            ref={ref => (this.contentRef = ref)}
            direction={
              this.props.chartPosition === "vertical" ? "column" : "row"
            }
          >
            <ChartSide
              basis={100 - legendBasis}
              order={this.props.legendPosition === "after" ? 0 : 2}
            >
              {(() => {
                if (!this.contentRef) {
                  setTimeout(() => {
                    this.forceUpdate();
                  });
                  return null;
                }
                let props = {};
                if (this.props.chartPosition !== "vertical") {
                  props.height = this.contentRef.offsetHeight;
                  props.width =
                    this.contentRef.offsetWidth * ((100 - legendBasis) / 100) -
                    40;
                } else {
                  props.width = this.contentRef.offsetWidth;
                  props.height =
                    this.contentRef.offsetHeight * ((100 - legendBasis) / 100);
                }
                if (this.props.chartOptions) {
                  props.options = merge(
                    cloneDeep(this.props.chartOptions),
                    onChartClick
                  );
                }
                return (
                  <Chart
                    redraw={false}
                    {...props}
                    data={data}
                    legend={{ display: false }}
                  />
                );
              })()}
            </ChartSide>
            {!this.props.hideLegend &&
              this.props.chartPosition !== "vertical" && <Divider />}
            {!this.props.hideLegend &&
              this.props.chartPosition === "vertical" && <HorizontalDivider />}
            {!this.props.hideLegend && (
              <LegendSide
                basis={legendBasis}
                order={this.props.legendPosition === "after" ? 2 : 0}
              >
                <Legend data={this.props.legendData} />
              </LegendSide>
            )}
          </Content>
        </Container>
      </ThemeProvider>
    );
  }
}

export default BaseChart;
