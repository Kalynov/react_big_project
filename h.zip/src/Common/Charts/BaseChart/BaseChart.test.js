import React from "react";
import { configure, render, shallow, mount } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import BaseChart from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";
import { ThemeProvider } from "styled-components";
import Theme from "../../../theme";

const legendData = {
  names: {
    typeOne: "Название 1",
    typeTwo: "Название 2",
    typeThree: "Название 3"
  },
  values: {
    typeOne: 300,
    typeTwo: 50,
    typeThree: 100
  }
};

const chartData = {
  labels: ["Название 1", "Название 2", "Название 3"],
  datasets: [
    {
      data: [300, 50, 100],
      backgroundColor: Theme.chartsColors.slice(0, 3),
      hoverBackgroundColor: Theme.chartsColors.slice(0, 3)
    }
  ]
};

describe("BaseChart", () => {
  it("should render properly", () => {
    const component = render(
      <ThemeProvider theme={Theme}>
        <BaseChart
          title="Заголовок"
          chartData={chartData}
          legendData={legendData}
        />
      </ThemeProvider>
    );

    expect(component).toBeDefined();
  });

  it("should render properly with other props", () => {
    const component = render(
      <ThemeProvider theme={Theme}>
        <BaseChart
          title="Заголовок"
          chartData={chartData}
          legendData={legendData}
          customChart={jest.fn()}
          chartPosition="horizontal"
        />
      </ThemeProvider>
    );

    expect(component).toBeDefined();
  });

  it("should update properly", () => {
    const component = shallow(
      <ThemeProvider theme={Theme}>
        <BaseChart
          title="Заголовок"
          chartData={chartData}
          legendData={legendData}
          customChart={jest.fn()}
          chartPosition="horizontal"
        />
      </ThemeProvider>
    );

    component.setProps({
      chartPosition: "vertical"
    });

    expect(component).toBeDefined();
  });

  it("should match snapshot and try to draw canvas", () => {
    HTMLCanvasElement.prototype.getContext = jest.fn();

    const component = mount(
      <ThemeProvider theme={Theme}>
        <BaseChart
          title="Заголовок"
          chartData={chartData}
          legendData={legendData}
        />
      </ThemeProvider>
    );

    const instance = component.find("BaseChart").instance();
    instance.contentRef = {
      offsetHeight: 600,
      offsetWidth: 900
    };
    instance.forceUpdate();

    component.update();

    expect(toJson(component.find("BaseChart"))).toMatchSnapshot();
    expect(HTMLCanvasElement.prototype.getContext).toBeCalled();
  });

  it("should match snapshot vertical and try to draw canvas", () => {
    HTMLCanvasElement.prototype.getContext = jest.fn();

    const component = mount(
      <ThemeProvider theme={Theme}>
        <BaseChart
          addBorderColor
          title="Заголовок"
          chartData={chartData}
          legendData={legendData}
          legendPosition="before"
          chartPosition="vertical"
          legendBasis={7}
        />
      </ThemeProvider>
    );

    const instance = component.find("BaseChart").instance();
    instance.contentRef = {
      offsetHeight: 600,
      offsetWidth: 900
    };
    instance.forceUpdate();

    component.update();

    expect(toJson(component.find("BaseChart"))).toMatchSnapshot();
    expect(HTMLCanvasElement.prototype.getContext).toBeCalled();
  });
});
