import BaseChart from "./BaseChart";

export default BaseChart;
