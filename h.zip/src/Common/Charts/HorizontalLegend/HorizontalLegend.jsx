import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.HorizontalLegend использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const Container = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
  align-content: center;
  align-items: center;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.HorizontalLegend}
`;

const Icon = styled.div`
  height: 9px;
  width: 9px;
  border-radius: 9px;
  background-color: ${props => {
    const colors = props.theme.chartsColors;
    const index = props.order % (colors.length - 1);
    return colors[index];
  }};
  position: absolute;
  left: 0;
  top: 3px;
  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.HorizontalLegend__Icon};
`;

const Item = styled.div`
  flex: 0 1 auto;
  align-self: auto;

  display: block;
  margin-rigth: 25px;
  margin-left: 25px;
  padding-left: 17px;
  position: relative;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend__Item}
`;

const Title = styled.div`
  color: #888e9f;
  font-family: "ProximaNova-Regular";
  font-size: 14px;
  line-height: 17px;
  margin-bottom: 4px;
  white-space: nowrap;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.VerticalLegend__Title}
`;

class HorizontalLegend extends React.PureComponent {
  static propTypes = {
    data: PropTypes.shape({
      names: PropTypes.oneOfType([PropTypes.object, PropTypes.array])
    }).isRequired
  };

  static defaultProps = {};

  state = {};

  render() {
    return (
      <Container>
        {Object.keys(this.props.data.names).map((key, numKey) => {
          return (
            <Item key={key}>
              <Icon order={numKey} />
              <Title>{this.props.data.names[key]}</Title>
            </Item>
          );
        })}
      </Container>
    );
  }
}

export default HorizontalLegend;
