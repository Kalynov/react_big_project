import HorizontalLegend from "./HorizontalLegend";

export default HorizontalLegend;
