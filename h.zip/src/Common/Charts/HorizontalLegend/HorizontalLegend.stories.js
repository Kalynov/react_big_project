import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import HorizontalLegend from "./HorizontalLegend";

const options = {
  info: {
    inline: false,
    text: `
    Charts - HorizontalLegend.

    Выводит горизонтальный вариант легенды для графиков.

    ~~~
    import { HorizontalLegend } from "heaven-components/dist/Common";
    ~~~

    [Ссылка на дизайн](https://projects.invisionapp.com/d/main#/console/13027675/307260491/preview)
    [Ссылка на Jira](https://jira-new.skytracking.ru/browse/STS-355)

    Ключевые слова: график, легенда, информация, статистика, аналитика, отчет.
  `
  }
};

storiesOf("Charts|HorizontalLegend", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["HorizontalLegend"] })

  .add(
    "Стандартный вид",
    () => (
      <HorizontalLegend
        data={{
          names: {
            typeOne: "Название 1",
            typeTwo: "Название 2",
            typeThree: "Название 3"
          }
        }}
      />
    ),
    options
  );
