import React from "react";
import { configure, render, shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import HorizontalLegend from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";
import { ThemeProvider } from "styled-components";
import Theme from "../../../theme";

const props = {
  data: {
    names: {
      typeOne: "Название 1",
      typeTwo: "Название 2",
      typeThree: "Название 3"
    },
    values: {
      typeOne: 10,
      typeTwo: 20,
      typeThree: 30
    }
  }
};

describe("HorizontalLegend", () => {
  it("should render properly", () => {
    const component = render(
      <ThemeProvider theme={Theme}>
        <HorizontalLegend {...props} />
      </ThemeProvider>
    );

    expect(component).toBeDefined();
  });

  it("should match snapshot", () => {
    const component = render(
      <ThemeProvider theme={Theme}>
        <HorizontalLegend {...props} />
      </ThemeProvider>
    );

    expect(toJson(component)).toMatchSnapshot();
  });
});
