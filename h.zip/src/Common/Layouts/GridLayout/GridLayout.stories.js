import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import GridLayout from "./GridLayout";
import BaseChart from "../../Charts/BaseChart";
import styled from "styled-components";

const PageBackground = styled.div`
  background: #f5f8fa;
  padding: 10px;
`;

const SampleBlock = styled.div`
  background: #c4c4c4;
  position: absolute;
  height: 100%;
  width: 100%;
`;

const legendData = {
  names: {
    typeOne: "Название 1",
    typeTwo: "Название 2",
    typeThree: "Название 3"
  },
  values: {
    typeOne: 300,
    typeTwo: 50,
    typeThree: 100
  }
};

const chartData = {
  labels: ["Название 1", "Название 2", "Название 3"],
  datasets: [
    {
      data: [300, 50, 100]
    }
  ]
};

const lineChartData = {
  labels: ["1", "2", "3"],
  datasets: [
    {
      data: [300, 50, 100]
    }
  ]
};

const options = {
  info: {
    inline: false,
    text: `
    Layouts - GridLayout.

    Располагает переданные компоненты в сетке.

    ~~~
    import { GridLayout } from "heaven-components/dist/Common";
    ~~~

    [Ссылка на частичный дизайн](https://projects.invisionapp.com/d/main#/console/13027675/310500124/preview)

    [Ссылка на Jira](https://jira-new.skytracking.ru/browse/STS-355)

    Ключевые слова: разметка, сетка, таблица, страница.
  `
  }
};

storiesOf("Layouts|GridLayout", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["GridLayout"] })
  .addDecorator(story => <PageBackground>{story()}</PageBackground>)

  .add(
    "Стандартный вид",
    () => (
      <GridLayout
        cellsData={[
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 1
            },
            bottomRight: {
              col: 5,
              row: 4
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 6,
              row: 1
            },
            bottomRight: {
              col: 7,
              row: 3
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 8,
              row: 1
            },
            bottomRight: {
              col: 12,
              row: 3
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 6,
              row: 4
            },
            bottomRight: {
              col: 12,
              row: 5
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 5
            },
            bottomRight: {
              col: 5,
              row: 5
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 6
            },
            bottomRight: {
              col: 12,
              row: 6
            }
          }
        ]}
      />
    ),
    options
  )

  .add(
    "С пустыми ячейками",
    () => (
      <GridLayout
        showEmptyCells
        cellsData={[
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 1
            },
            bottomRight: {
              col: 5,
              row: 4
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 8,
              row: 1
            },
            bottomRight: {
              col: 12,
              row: 3
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 6,
              row: 4
            },
            bottomRight: {
              col: 12,
              row: 5
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 6
            },
            bottomRight: {
              col: 12,
              row: 6
            }
          }
        ]}
      />
    ),
    options
  )

  .add(
    "С графиками внутри",
    () => (
      <GridLayout
        showEmptyCells
        cellsData={[
          {
            component: (
              <BaseChart
                title="AAAAAAAA"
                chartData={chartData}
                legendData={legendData}
                chartType="HorizontalBar"
              />
            ),
            topLeft: {
              col: 1,
              row: 1
            },
            bottomRight: {
              col: 5,
              row: 3
            }
          },
          {
            component: (
              <BaseChart
                title="AAAAAAAA"
                chartData={chartData}
                legendData={legendData}
                chartPosition="vertical"
                legendBasis={10}
                chartType="Doughnut"
              />
            ),
            topLeft: {
              col: 6,
              row: 1
            },
            bottomRight: {
              col: 9,
              row: 3
            }
          },
          {
            component: (
              <BaseChart
                title="AAAAAAAA"
                chartData={chartData}
                legendData={legendData}
                chartPosition="vertical"
                legendBasis={10}
              />
            ),
            topLeft: {
              col: 10,
              row: 1
            },
            bottomRight: {
              col: 12,
              row: 3
            }
          },
          {
            component: (
              <BaseChart
                title="AAAAAAAA"
                chartData={chartData}
                legendData={legendData}
              />
            ),
            topLeft: {
              col: 1,
              row: 4
            },
            bottomRight: {
              col: 4,
              row: 6
            }
          },
          {
            component: (
              <BaseChart
                title="AAAAAAAA"
                chartData={lineChartData}
                legendData={legendData}
                chartPosition="vertical"
                legendBasis={10}
                chartType="Line"
                addBorderColor
                addBackgroundColor={false}
              />
            ),
            topLeft: {
              col: 5,
              row: 4
            },
            bottomRight: {
              col: 9,
              row: 6
            }
          },
          {
            component: (
              <BaseChart
                title="AAAAAAAA"
                chartData={chartData}
                legendData={legendData}
                chartPosition="vertical"
                chartType="Bar"
                hideLegend
              />
            ),
            topLeft: {
              col: 10,
              row: 4
            },
            bottomRight: {
              col: 12,
              row: 6
            }
          },
          {
            component: (
              <BaseChart
                title="AAAAAAAA"
                chartData={lineChartData}
                legendData={legendData}
                chartPosition="vertical"
                legendBasis={10}
                chartType="Line"
                addBorderColor
                addBackgroundColor={false}
              />
            ),
            topLeft: {
              col: 1,
              row: 7
            },
            bottomRight: {
              col: 6,
              row: 10
            }
          },
          {
            component: (
              <BaseChart
                chartPosition="vertical"
                legendBasis={0}
                titleFontSize={14}
                title="Объекты"
                chartOptions={{
                  scales: {
                    xAxes: [
                      {
                        stacked: true
                      }
                    ],
                    yAxes: [
                      {
                        stacked: true
                      }
                    ]
                  }
                }}
                chartData={{
                  labels: [
                    "Название 81",
                    "Название 81",
                    "Название 55",
                    "Название 85",
                    "Название 47",
                    "Название 24",
                    "Название 53",
                    "Название 68",
                    "Название 72",
                    "Название 52",
                    "Название 90",
                    "Название 10",
                    "Название 9"
                  ],
                  datasets: [
                    {
                      data: [81, 81, 55, 85, 47, 24, 53, 68, 72, 52, 90, 10, 9]
                    },
                    {
                      data: [10, 11, 52, 11, 75, 35, 87, 15, 47, 75, 1, 14, 90]
                    }
                  ]
                }}
                legendData={legendData}
                chartType="HorizontalBar"
                hideLegend
              />
            ),
            topLeft: {
              col: 7,
              row: 7
            },
            bottomRight: {
              col: 12,
              row: 10
            }
          }
        ]}
      />
    ),
    options
  );
