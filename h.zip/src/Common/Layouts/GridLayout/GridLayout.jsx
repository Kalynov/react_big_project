import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";
import { isEqual } from "lodash";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.GridLayout использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const Container = styled.div`
  display: grid;
  grid-template-columns: ${props =>
    (props.cellSize + "px ").repeat(props.cols)};
  grid-template-rows: ${props => (props.cellSize + "px ").repeat(props.rows)};
  grid-gap: ${props => props.gapSize}px;

  background: ${props => props.bg};

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.GridLayout}
`;

const Cell = styled.div`
  position: relative;
  grid-area: ${props =>
    `${props.topLeft.row} / ${props.topLeft.col} / ${props.bottomRight.row} / ${
      props.bottomRight.col
    }`};

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.GridLayout__Cell}
`;

const BgColor = "#e0e4f1";
const DotColor = "#888E9F";
const DotSize = 1;

const EmptyCell = styled(Cell).attrs({
  style: ({ dotSpace }) => ({
    background: `linear-gradient(
            90deg,
            ${BgColor} ${dotSpace - DotSize}px,
            transparent 1%
          )
          center,
        linear-gradient(${BgColor} ${dotSpace -
      DotSize}px, transparent 1%) center,
        ${DotColor}`,
    backgroundSize: `${dotSpace}px ${dotSpace}px`,
    backgroundPosition: `${dotSpace / 2}px ${dotSpace / 2}px`
  })
})``;

class GridLayout extends React.PureComponent {
  static propTypes = {
    /** Количество столбцов */
    cols: PropTypes.number,
    /** Отступы между ячейками */
    gapSize: PropTypes.number,
    /** Показывать пустые ячейки */
    showEmptyCells: PropTypes.bool,
    /** Данные для ячеек */
    cellsData: PropTypes.arrayOf(
      PropTypes.shape({
        component: PropTypes.node,
        topLeft: PropTypes.shape({
          col: PropTypes.number,
          row: PropTypes.number
        }),
        bottomRight: PropTypes.shape({
          col: PropTypes.number,
          row: PropTypes.number
        })
      })
    ),
    /** Фон сетки */
    background: PropTypes.string
  };

  static defaultProps = {
    cols: 12,
    gapSize: 10,
    showEmptyCells: false,
    cellsData: [],
    background: "#F5F8FA"
  };

  state = {
    sizeCalculated: false
  };

  constructor(props) {
    super(props);

    this.handleResize = this.handleResize.bind(this);
  }

  componentDidMount() {
    window.addEventListener("resize", this.handleResize);
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.handleResize);
  }

  componentDidUpdate(prevProps) {
    if (
      this.props.cols !== prevProps.cols ||
      !isEqual(this.props.cellsData, prevProps.cellsData)
    ) {
      this.setState({
        sizeCalculated: false
      });
    }
  }

  handleResize() {
    this.setState({
      sizeCalculated: false
    });
  }

  render() {
    let cellSize = 0;
    if (this.containerRef && !this.props.sizeCalculated) {
      cellSize =
        (this.containerRef.offsetWidth -
          this.props.gapSize * (this.props.cols - 1)) /
        this.props.cols;
      setTimeout(() => {
        this.setState({
          sizeCalculated: true
        });
      });
    } else {
      setTimeout(() => {
        this.forceUpdate();
      });
    }

    let rows = 0;
    let notEmptyCells = [];
    const cells = this.props.cellsData.map((cell, key) => {
      if (cell.bottomRight.row > rows) {
        rows = cell.bottomRight.row;
      }
      for (let row = cell.topLeft.row; row <= cell.bottomRight.row; row++) {
        if (!notEmptyCells[row]) notEmptyCells[row] = [];
        for (let col = cell.topLeft.col; col <= cell.bottomRight.col; col++) {
          notEmptyCells[row][col] = true;
        }
      }
      return (
        <Cell
          key={key}
          topLeft={cell.topLeft}
          bottomRight={{
            row: cell.bottomRight.row + 1,
            col: cell.bottomRight.col + 1
          }}
        >
          {cell.component}
        </Cell>
      );
    });

    let emptyCells = [];
    if (this.props.showEmptyCells) {
      if (rows == 0) rows = 2;
      for (let row = 1; row <= rows; row++) {
        for (let col = 1; col <= this.props.cols; col++) {
          if (
            typeof notEmptyCells[row] === "undefined" ||
            typeof notEmptyCells[row][col] === "undefined"
          ) {
            emptyCells.push(
              <EmptyCell
                key={`empty ${row} - ${col}`}
                dotSpace={cellSize / 9}
                topLeft={{ row, col }}
                bottomRight={{ row: row + 1, col: col + 1 }}
              />
            );
          }
        }
      }
    }

    return (
      <Container
        ref={ref => (this.containerRef = ref)}
        cellSize={cellSize}
        gapSize={this.props.gapSize}
        cols={this.props.cols}
        rows={rows}
        bg={this.containerRef && this.props.background}
      >
        {this.state.sizeCalculated && emptyCells}
        {this.state.sizeCalculated && cells}
      </Container>
    );
  }
}

export default GridLayout;
