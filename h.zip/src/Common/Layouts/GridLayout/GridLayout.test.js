import React from "react";
import { configure, mount, shallow, render } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import GridLayout from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";
import { ThemeProvider } from "styled-components";
import Theme from "../../../theme";
import styled from "styled-components";

const SampleBlock = styled.div`
  background: #c4c4c4;
  position: absolute;
  height: 100%;
  width: 100%;
`;

describe("GridLayout", () => {
  it("should render properly", () => {
    const component = mount(
      <ThemeProvider theme={Theme}>
        <GridLayout />
      </ThemeProvider>
    );

    expect(component).toBeDefined();
  });

  it("should listen resize on window", () => {
    const addEventListener = jest.fn();
    window.addEventListener = addEventListener;

    const component = mount(
      <ThemeProvider theme={Theme}>
        <GridLayout />
      </ThemeProvider>
    );

    component.update();

    expect(addEventListener).toBeCalled();
  });

  it("should unlisten resize on window when unmounts", () => {
    const removeEventListener = jest.fn();
    window.removeEventListener = removeEventListener;

    const component = mount(
      <ThemeProvider theme={Theme}>
        <GridLayout />
      </ThemeProvider>
    );

    component.unmount();

    expect(removeEventListener).toBeCalled();
  });

  it("should match snapshot with no data", () => {
    const component = mount(<GridLayout />);

    const instance = component.instance();

    instance.containerRef = {
      offsetWidth: 1000
    };

    instance.state.sizeCalculated = true;
    instance.forceUpdate();

    component.update();

    expect(toJson(component.find("GridLayout"))).toMatchSnapshot();
  });

  it("should match snapshot with empty cells", () => {
    const component = mount(<GridLayout showEmptyCells />);

    const instance = component.instance();

    instance.containerRef = {
      offsetWidth: 1000
    };

    instance.state.sizeCalculated = true;
    instance.forceUpdate();

    component.update();

    expect(toJson(component.find("GridLayout"))).toMatchSnapshot();
  });

  it("should match snapshot with bigger width", () => {
    const component = mount(<GridLayout showEmptyCells />);

    const instance = component.instance();

    instance.containerRef = {
      offsetWidth: 10000
    };

    instance.state.sizeCalculated = true;
    instance.forceUpdate();

    component.update();

    expect(toJson(component.find("GridLayout"))).toMatchSnapshot();
  });

  it("should match snapshot with some blocks", () => {
    const component = mount(
      <GridLayout
        showEmptyCells
        cellsData={[
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 1
            },
            bottomRight: {
              col: 5,
              row: 4
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 8,
              row: 1
            },
            bottomRight: {
              col: 12,
              row: 3
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 5
            },
            bottomRight: {
              col: 5,
              row: 5
            }
          },
          {
            component: <SampleBlock />,
            topLeft: {
              col: 1,
              row: 6
            },
            bottomRight: {
              col: 12,
              row: 6
            }
          }
        ]}
      />
    );

    const instance = component.instance();

    instance.containerRef = {
      offsetWidth: 1000
    };

    instance.state.sizeCalculated = true;
    instance.forceUpdate();

    component.update();

    expect(toJson(component.find("GridLayout"))).toMatchSnapshot();
  });
});
