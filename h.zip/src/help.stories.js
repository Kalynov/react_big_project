import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import Theme from "./theme";
import treeify from "treeify";

const themeTree = treeify.asTree(Theme, true);

storiesOf("Помощь по Heaven Components", module)
  .addDecorator(withInfo)

  .add(
    "Установка библиотеки",
    () => {
      return;
    },
    {
      info: {
        inline: true,
        source: false,
        text: `
        ## Установка

        ~~~
        npm set registry http://heaven-test01.skytracking.ru:4873
        npm i --save heaven-components
        ~~~

        ## Настройка

        В App.js (или аналоге)

        ~~~
        import { ThemeProvider } from "styled-components";
        import { default as DefaultTheme} from "heaven-components/dist/theme";

        <ThemeProvider theme={DefaultTheme}>
          {/* Здесь остальное приложение */}
        </ThemeProvider>
        ~~~
      `
      }
    }
  )

  .add(
    "Изменение темы",
    () => {
      return;
    },
    {
      info: {
        inline: true,
        source: false,
        text: `
        ## Изменение темы

        В App.js (или аналоге)

        ~~~
        import { ThemeProvider } from "styled-components";
        import { default as DefaultTheme} from "heaven-components/dist/theme";
        import MyTheme from "./my-theme.js";

        <ThemeProvider theme={{...DefaultTheme, ...MyTheme}}>
          {/* Здесь остальное приложение */}
        </ThemeProvider>
        ~~~
      `
      }
    }
  )

  .add(
    "Импортирование компонентов",
    () => {
      return;
    },
    {
      info: {
        inline: true,
        source: false,
        text: `
        ~~~
        import { TestComponent } from "heaven-components/dist/STTS";
        ~~~
      `
      }
    }
  )

  .add(
    "Список ключей и значений темы",
    () => {
      return;
    },
    {
      info: {
        inline: true,
        source: false,
        text: `
~~~
${themeTree}
~~~
      `
      }
    }
  )

  .add(
    "Разработка новых компонентов",
    () => {
      return;
    },
    {
      info: {
        inline: true,
        source: false,
        text: `
        ## Создание шаблона

        ~~~
        git pull
        npm run new
        ~~~


        ## Запуск storybook

        ~~~
        npm run storybook
        ~~~


        ## Тесты

        https://devhints.io/enzyme

        Простой запуск
        ~~~
        npm run test
        ~~~

        Автоматическое выполнение
        ~~~
        npm run test -- --watchAll
        ~~~

        Для storybook
        ~~~
        npm run test:generate-output -- --watchAll
        ~~~

      `
      }
    }
  )

  .add(
    "Решение проблем",
    () => {
      return;
    },
    {
      info: {
        inline: true,
        source: false,
        text: `
        ## Предупреждение о дублировании styled-components

        Добавьте в конфиг webpack

        ~~~
        resolve: {
          // ...
          alias: {
            // ...
            "styled-components": path.resolve(
              __dirname,
              "node_modules",
              "styled-components"
            )
          }
        },
        ~~~
      `
      }
    }
  );
