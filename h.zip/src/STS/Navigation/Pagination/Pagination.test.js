import React from "react";
import { configure, render, shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import Pagination from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";
import { ThemeProvider } from "styled-components";
import Theme from "../../../theme";

describe("Pagination", () => {
  it("should render properly", () => {
    const component = render(
      <ThemeProvider theme={Theme}>
        <Pagination startPage={1} endPage={100} currentPage={20} />
      </ThemeProvider>
    );

    expect(component).toBeDefined();
  });

  it("should call callback on click", () => {
    const onChange = jest.fn();

    const component = shallow(
      <Pagination
        onChange={onChange}
        startPage={1}
        endPage={100}
        currentPage={50}
      />
    );

    component
      .find("PaginationButton")
      .first()
      .simulate("click");

    expect(onChange).toBeCalled();
  });

  it("should call callback on click on number item", () => {
    const onChange = jest.fn();

    const component = shallow(
      <Pagination
        onChange={onChange}
        startPage={1}
        endPage={100}
        currentPage={50}
      />
    );

    component
      .find("PaginationButton")
      .at(1)
      .simulate("click");

    expect(onChange).toBeCalled();
  });

  it("should call callback on click on last item", () => {
    const onChange = jest.fn();

    const component = shallow(
      <Pagination
        onChange={onChange}
        startPage={1}
        endPage={100}
        currentPage={50}
      />
    );

    component
      .find("PaginationButton")
      .last()
      .simulate("click");

    expect(onChange).toBeCalled();
  });

  it("should call callback on click on jump", () => {
    const onChange = jest.fn();

    const component = shallow(
      <Pagination
        onChange={onChange}
        startPage={1}
        endPage={100}
        currentPage={50}
      />
    );

    component
      .find("PaginationButton[jump=true]")
      .first()
      .simulate("click");

    expect(onChange).toBeCalled();
  });

  it("should call callback on click on jump", () => {
    const onChange = jest.fn();

    const component = shallow(
      <Pagination
        onChange={onChange}
        startPage={1}
        endPage={100}
        currentPage={50}
      />
    );

    component
      .find("PaginationButton[jump=true]")
      .last()
      .simulate("click");

    expect(onChange).toBeCalled();
  });

  it("should match snapshot", () => {
    const component = render(
      <Pagination startPage={1} endPage={100} currentPage={20} />
    );

    expect(toJson(component)).toMatchSnapshot();
  });
});
