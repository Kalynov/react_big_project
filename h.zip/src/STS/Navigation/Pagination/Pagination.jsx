import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.Pagination использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const PaginationContainer = styled.div`
  font-size: 12px;

  font-family: "Arial";
  ${/* istanbul ignore next */ props => props.theme.Pagination}
`;

const PaginationButton = styled.div`
  color: ${props => (props.active ? "#FFFFFF" : "#666")};
  float: left;
  cursor: pointer;
  transition: all 0.3s ease-out;
  box-sizing: border-box;
  border: ${props => (props.jump ? 0 : 1)}px solid #e0e4f1;
  padding: ${props =>
    props.jump ? "17.5px 16.5px 14.5px 16.5px" : "13.5px 16.5px 13.5px 16.5px"};
  font-size: 14px;
  background-color: ${props =>
    props.jump
      ? "transparent"
      : props.active
      ? props.theme.STS
        ? props.theme.STS.colors.PrimaryColor
        : null
      : "#FFFFFF"};
  margin-left: 0px;
  outline: none;
  ${props => (props.jump ? "." : ":hover")} {
    background-color: ${props =>
      props.theme.STS ? props.theme.STS.colors.PrimaryColor : null};
    color: #ffffff;
  }

  ${/* istanbul ignore next */ props =>
    props.theme.Pagination__PaginationButton}
`;

const More = styled.span`
  display: block;
  letter-spacing: 2px;
  color: #ccc;
  font-size: 12px;
  ${/* istanbul ignore next */ props => props.theme.Pagination__More}
`;

class Pagination extends React.PureComponent {
  state = {};

  static propTypes = {
    /**
     * Первая страница
     */
    startPage: PropTypes.number.isRequired,
    /**
     * Последняя страница
     */
    endPage: PropTypes.number.isRequired,
    /**
     * Текущая страница
     */
    currentPage: PropTypes.number.isRequired,

    /**
     * Сколько страниц показывать рядом с текущей
     */
    maxClosestPages: PropTypes.number,

    /**
     * Текст кнопки "назад"
     */
    prevPageText: PropTypes.string,
    /**
     * Текст кнопки "вперед"
     */
    nextPageText: PropTypes.string,

    /**
     * Событие изменения
     */
    onChange: PropTypes.func
  };

  static defaultProps = {
    maxClosestPages: 2,

    prevPageText: "Предыдущая",
    nextPageText: "Следующая"
  };

  constructor(props) {
    super(props);

    this.onButtonClick = this.onButtonClick.bind(this);
  }

  static getDerivedStateFromProps(props) {
    return props;
  }

  showNumber(number) {
    return (
      <PaginationButton
        onClick={() => {
          this.onButtonClick(number);
        }}
        key={number}
        active={number == this.state.currentPage}
      >
        {number}
      </PaginationButton>
    );
  }

  onButtonClick(number) {
    number = Math.min(number, this.state.endPage);
    number = Math.max(number, this.state.startPage);
    if (this.props.onChange) {
      this.props.onChange(number);
    }
  }

  render() {
    let buttonsStart = Math.max(
      this.state.startPage + 1,
      this.state.currentPage - this.state.maxClosestPages
    );
    let buttonsEnd = Math.min(
      this.state.endPage - 1,
      this.state.currentPage + this.state.maxClosestPages
    );
    let buttons = [];
    for (let i = buttonsStart; i <= buttonsEnd; i++) {
      buttons.push(this.showNumber(i));
    }
    return (
      <PaginationContainer>
        {this.state.currentPage > this.state.startPage && (
          <PaginationButton
            onClick={() => {
              this.onButtonClick(this.state.currentPage - 1);
            }}
          >
            {this.state.prevPageText}
          </PaginationButton>
        )}
        {this.showNumber(this.state.startPage)}
        {buttonsStart != this.state.startPage + 1 && (
          <PaginationButton
            jump
            onClick={() => {
              this.onButtonClick(buttonsStart - this.state.maxClosestPages);
            }}
          >
            <More>•••</More>
          </PaginationButton>
        )}
        {buttons}
        {buttonsEnd != this.state.endPage - 1 && (
          <PaginationButton
            jump
            onClick={() => {
              this.onButtonClick(buttonsEnd + this.state.maxClosestPages);
            }}
          >
            <More>•••</More>
          </PaginationButton>
        )}
        {this.showNumber(this.state.endPage)}
        {this.state.currentPage < this.state.endPage && (
          <PaginationButton
            onClick={() => {
              this.onButtonClick(this.state.currentPage + 1);
            }}
          >
            {this.state.nextPageText}
          </PaginationButton>
        )}
      </PaginationContainer>
    );
  }
}

export default Pagination;
