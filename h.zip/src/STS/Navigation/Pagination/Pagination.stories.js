import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import Pagination from "./Pagination";

const options = {
  info: {
    inline: false,
    text: `
    Это простой компонент Pagination.

    Выводит пагинацию. По ширине не адаптируется.

    ~~~
    import { Pagination } from "heaven-components/dist/STS";
    ~~~

    Дизайн был в проекте STS, но, похоже, был удален в процессе правок дизайнерами.
  `
  }
};

storiesOf("Navigation|Pagination/[STS]", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["Pagination"] })

  .add(
    "Стандартный вид",
    () => <Pagination startPage={1} endPage={4} currentPage={2} />,
    options
  )

  .add(
    "С сокращениями",
    () => <Pagination startPage={1} endPage={100} currentPage={20} />,
    options
  );
