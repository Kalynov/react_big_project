import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.Input использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const StyledInputContainer = styled.div`
  ${/* istanbul ignore next */ props => props.theme.globalStyle}

  width: 100%;
  margin-bottom: ${props => props.theme.STS.margins.default};
  border: 1px solid ${props => props.theme.STS.colors.BorderColor};

  ${/* istanbul ignore next */ props => props.theme.Input}
`;

const StyledInput = styled.input`
  outline: none;
  color: ${props => props.theme.STS.colors.PrimaryColor};
  border: none;
  max-width: 100%;
  padding: 10px 0 10px 15px;
  flex: 1 1 auto;
`;

class Input extends React.PureComponent {
  static propTypes = {
    /** Текст, выводящийся при пустом поле */
    placeholder: PropTypes.string
  };

  static defaultProps = {
    placeholder: ""
  };

  render() {
    return (
      <StyledInputContainer>
        <StyledInput {...this.props} />
      </StyledInputContainer>
    );
  }
}

export default Input;
