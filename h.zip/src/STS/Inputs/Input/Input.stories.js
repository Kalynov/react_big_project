import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import Input from "./Input";

storiesOf("Inputs|Input/[STS]", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["Input"] })

  .add(
    "Стандартный вид",
    () => <Input onChange={action("on-change")} placeholder="Текстовое поле" />,
    {
      info: {
        inline: false,
        text: `
        Простое поле для ввода текста.

        ~~~js
        import { Input } from "heaven-components/dist/STS";
        ~~~

        [Ссылка на дизайн](https://projects.invisionapp.com/d/main#/console/13575035/325414219/preview)
      `
      }
    }
  );
