import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import ToastItem from "./ToastItem";

const options = {
  info: {
    inline: false,
    text: `
    Это сложный компонент ToastItem.

    Выводит блок оповещения, может закрываться по таймауту или по клику.

    ~~~
    import { ToastItem } from "heaven-components/dist/STS";
    ~~~

    [Ссылка на дизайн](https://projects.invisionapp.com/d/main#/console/13575035/291165236/preview)
  `
  }
};

storiesOf("Notifications|Notification/[STS]", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["ToastItem"] })

  .add(
    "Стандартный вид",
    () => (
      <ToastItem
        autoClose={false}
        title="Заголовок оповещения"
        text="Текст оповещения"
      />
    ),
    options
  )

  .add(
    "Уведомление об успешном состоянии",
    () => (
      <ToastItem
        autoClose={false}
        state="success"
        title="Заголовок оповещения"
        text="Текст оповещения"
      />
    ),
    options
  )

  .add(
    "Уведомление средней критичности",
    () => (
      <ToastItem
        autoClose={false}
        state="warning"
        title="Заголовок оповещения"
        text="Текст оповещения"
      />
    ),
    options
  )

  .add(
    "Критическое уведомление",
    () => (
      <ToastItem
        autoClose={false}
        state="danger"
        title="Заголовок оповещения"
        text="Текст оповещения"
      />
    ),
    options
  );
