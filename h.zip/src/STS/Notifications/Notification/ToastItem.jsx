import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";
import classNames from "classnames";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.ToastItem использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const textColors = {
  info: "#000000",
  warning: "#000000",
  success: "#000000",
  danger: "#FFFFFF"
};

const Container = styled.div`
  height: 70px;
  width: 324px;
  min-width: 20vw;
  border-radius: 4px;
  margin-bottom: 22px;
  background-color: ${props =>
    props.theme.STS ? props.theme.STS.colors[props.state] : false};
  color: ${props => textColors[props.state]};

  padding: 16px;
  font-family: "ProximaNova-Regular";
  cursor: pointer;

  transition: 0.7s background-color,
    ${props => props.closingAnimationDuration / 1000}s transform
      cubic-bezier(0.1, 0.23, 0.24, 1.01),
    ${props => props.closingAnimationDuration / 1000}s opacity
      cubic-bezier(0.1, 0.23, 0.24, 1.01);
  &.appeared {
    transition: ${props => props.appearAnimationDuration / 1000}s opacity
      cubic-bezier(0.1, 0.23, 0.24, 1.01);
    opacity: 0;
  }
  &.closing {
    transform: translate(100%);
    opacity: 0;
  }
  &:last-of-type {
    margin-bottom: 0;
  }

  &:hover {
    background-color: ${props =>
      props.theme.STS ? props.theme.STS.colors[props.state] : false};
  }

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.ToastItem}
`;

const Title = styled.div`
  font-size: 14px;
  line-height: 17px;
  margin-bottom: 4px;
  ${/* istanbul ignore next */ props => props.theme.ToastItem__Title}
`;

const Text = styled.div`
  opacity: 0.54;
  font-size: 14px;
  line-height: 17px;
  ${/* istanbul ignore next */ props => props.theme.ToastItem__Text}
`;

class ToastItem extends React.PureComponent {
  static propTypes = {
    /**
     * Внешний вид уведомления
     * @type {string}
     */
    state: PropTypes.oneOf(["success", "info", "warning", "danger"]),
    /**
     * Текст для заголовка
     * @type {string}
     */
    title: PropTypes.string,
    /**
     * Текст оповещения
     * @type {string}
     */
    text: PropTypes.string,
    /**
     * Клик по оповещению
     * @type {func}
     */
    onClick: PropTypes.func,
    /**
     * Перед закрытием уведомления
     * @type {func}
     */
    onClose: PropTypes.func,
    /**
     * Время появления уведомления в мс
     * @type {number}
     */
    appearAnimationDuration: PropTypes.number,
    /**
     * Время скрытия уведомления в мс
     * @type {number}
     */
    closingAnimationDuration: PropTypes.number,
    /**
     * Закрывать ли оповещения по времени
     * @type {bool}
     */
    autoClose: PropTypes.bool,
    /**
     * Время в мс до закрытия оповещения
     * @type {number}
     */
    closeTimeout: PropTypes.number,
    /**
     * Close notification on click or not
     * @type {bool}
     */
    closeOnClick: PropTypes.bool
  };

  static defaultProps = {
    state: "info",
    title: "",
    text: "",
    closingAnimationDuration: 300,
    appearAnimationDuration: 300,
    autoClose: true,
    closeTimeout: 5000,
    closeOnClick: true
  };

  state = {
    closingAnimationStarted: false,
    firstRender: true
  };

  closingTimeout = null;
  closeTimeout = null;

  componentDidMount() {
    this.setCloseTimeout();
  }

  setCloseTimeout() {
    if (this.props.autoClose) {
      clearTimeout(this.closeTimeout);
      this.closeTimeout = setTimeout(() => {
        this.close();
      }, this.props.closeTimeout);
    }
  }

  componentWillUnmount() {
    clearTimeout(this.closingTimeout);
    clearTimeout(this.closeTimeout);
  }

  close() {
    this.setState({
      closingAnimationStarted: true
    });
    this.closingTimeout = setTimeout(() => {
      if (this.props.onClose) {
        this.props.onClose();
      }
    }, this.props.closingAnimationDuration);
  }

  render() {
    setTimeout(() => {
      this.setState({
        firstRender: false
      });
    }, 1);
    return (
      <Container
        onClick={() => {
          if (this.props.onClick) {
            this.props.onClick();
          }
          if (!this.props.autoClose || this.props.closeOnClick) {
            this.close();
          }
        }}
        onMouseOver={() => {
          clearTimeout(this.closeTimeout);
        }}
        onMouseOut={() => {
          this.setCloseTimeout();
        }}
        className={classNames({
          closing: this.state.closingAnimationStarted,
          appeared: this.state.firstRender
        })}
        state={this.props.state}
        closingAnimationDuration={this.props.closingAnimationDuration}
        appearAnimationDuration={this.props.appearAnimationDuration}
      >
        <Title>{this.props.title}</Title>
        <Text>{this.props.text}</Text>
      </Container>
    );
  }
}

export default ToastItem;
