import React from "react";
import { configure, render, shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import ToastItem from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";
import { ThemeProvider } from "styled-components";
import Theme from "../../../theme";

describe("ToastItem", () => {
  it("should render properly", () => {
    const component = shallow(<ToastItem />);

    expect(component).toBeDefined();
  });

  it("should match snapshot", () => {
    const component = render(
      <ThemeProvider theme={Theme}>
        <ToastItem />
      </ThemeProvider>
    );

    expect(toJson(component)).toMatchSnapshot();
  });

  it("should match snapshot without theme", () => {
    const component = render(<ToastItem />);

    expect(toJson(component)).toMatchSnapshot();
  });

  it("should close automatically", () => {
    const onClose = jest.fn();
    return new Promise(resolve => {
      const props = {
        autoClose: true,
        closeTimeout: 100,
        closingAnimationDuration: 10,
        onClose
      };

      const component = shallow(<ToastItem {...props} />);

      setTimeout(() => {
        resolve();
      }, 600);
    }).then(() => {
      expect(onClose).toBeCalled();
    });
  });

  it("should close on click", () => {
    const onClose = jest.fn();

    return new Promise(resolve => {
      const props = {
        autoClose: false,
        closeOnClick: true,
        closeTimeout: 100,
        closingAnimationDuration: 10,
        onClose
      };

      const component = shallow(<ToastItem {...props} />);

      component.simulate("click");

      setTimeout(() => {
        resolve();
      }, 600);
    }).then(() => {
      expect(onClose).toBeCalled();
    });
  });

  it("should call callback on click", () => {
    const onClick = jest.fn();

    return new Promise(resolve => {
      const props = {
        onClick
      };

      const component = shallow(<ToastItem {...props} />);

      component.simulate("click");

      setTimeout(() => {
        resolve();
      });
    }).then(() => {
      expect(onClick).toBeCalled();
    });
  });

  it("should not close close on hover", () => {
    const onClose = jest.fn();
    return new Promise(resolve => {
      const props = {
        autoClose: true,
        closeTimeout: 100,
        closingAnimationDuration: 10,
        onClose
      };

      const component = shallow(<ToastItem {...props} />);

      component.simulate("mouseover");

      setTimeout(() => {
        resolve();
      }, 600);
    }).then(() => {
      expect(onClose).not.toBeCalled();
    });
  });

  it("should close after mouse out", () => {
    const onClose = jest.fn();
    return new Promise(resolve => {
      const props = {
        autoClose: true,
        closeTimeout: 100,
        closingAnimationDuration: 10,
        onClose
      };

      const component = shallow(<ToastItem {...props} />);

      component.simulate("mouseover");

      setTimeout(() => {
        component.simulate("mouseout");
      }, 200);

      setTimeout(() => {
        resolve();
      }, 600);
    }).then(() => {
      expect(onClose).toBeCalled();
    });
  });

  it("should unmounts properly", () => {
    const component = shallow(<ToastItem />);
    component.unmount();

    expect(component).toBeDefined();
  });
});
