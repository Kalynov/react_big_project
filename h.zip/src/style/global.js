const global = `


  @font-face {
    font-family: "ProximaNova-Regular";
    src: url("./fonts/2E5F30_13_0.eot");
    src: url("./fonts/2E5F30_13_0-.eot#iefix")
        format("embedded-opentype"),
      url("./fonts/2E5F30_13_0.woff2") format("woff2"),
      url("./fonts/2E5F30_13_0.woff") format("woff"),
      url("./fonts/2E5F30_13_0.ttf") format("truetype");
    font-style: normal;
    font-weight: normal;
  }

  @font-face {
    font-family: "ProximaNova-Light";
    src: url("./fonts/2E5F30_11_0.eot");
    src: url("./fonts/2E5F30_11_0-.eot#iefix")
        format("embedded-opentype"),
      url("./fonts/2E5F30_11_0.woff2") format("woff2"),
      url("./fonts/2E5F30_11_0.woff") format("woff"),
      url("./fonts/2E5F30_11_0.ttf") format("truetype");
  }

  @font-face {
    font-family: "ProximaNova-Semibold";
    src: url("./fonts/2E5F30_12_0.eot");
    src: url("./fonts/2E5F30_12_0-.eot#iefix")
        format("embedded-opentype"),
      url("./fonts/2E5F30_12_0.woff2") format("woff2"),
      url("./fonts/2E5F30_12_0.woff") format("woff"),
      url("./fonts/2E5F30_12_0.ttf") format("truetype");
  }

  @font-face {
    font-family: "ProximaNova-Black";
    src: url("./fonts/2E5F30_10_0.eot");
    src: url("./fonts/2E5F30_10_0-.eot#iefix")
        format("embedded-opentype"),
      url("./fonts/2E5F30_10_0.woff2") format("woff2"),
      url("./fonts/2E5F30_10_0.woff") format("woff"),
      url("./fonts/2E5F30_10_0.ttf") format("truetype");
  }
`;

export default global;
