import React from "react";
import { configure, render, shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import Input from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";

describe("Input", () => {
  it("should render properly", () => {
    const component = shallow(<Input />);

    expect(component).toBeDefined();
  });

  it("should match snapshot", () => {
    const component = render(<Input />);

    expect(toJson(component)).toMatchSnapshot();
  });
});
