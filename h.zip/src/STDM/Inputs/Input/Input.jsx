import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

const Input = styled.input`
  width: 332px;
  height: 38px;
  padding: ${props => (props.background ? "0px 0 0px 43px" : "0px 0 0px 10px")};
  border: 1px solid #d0dfe8;
  font-family: ProximaNova-Regular, sans-serif;
  font-size: 100%;
  line-height: 1.15;
  margin: 0;
  background-color: #ffffff;
  color: #888e9f;
  padding-top: 1.9px;
  max-width: 100%;

  &:-webkit-autofill {
    -webkit-box-shadow: 0 0 0 30px white inset;
  }

  &:hover {
    border: 1px solid #788ece;
    color: #888e9f;
  }

  &:focus {
    border: 1px solid #b8c0d9;
    color: #000000;
  }

  ${props =>
    props.disabled
      ? `	border: 1px solid #E0E4F1;
      	opacity: 0.5;
        	background-color: #FFFFFF;
          user-select: none; 
          `
      : null}

  ${/* istanbul ignore next */ props => props.theme.Input}
`;

const InputForm = styled.div`
  width: 332px;
  height: 58px;
  ${/* istanbul ignore next */ props => props.theme.Input__InputForm}
`;

const InputErrorText = styled.div`
  margin-top: 5px;
  height: 9px;
  width: 101px;
  color: #de4d4d;
  font-size: 12px;
  line-height: 9px;
  ${/* istanbul ignore next */ props => props.theme.Input__InputErrorText}
`;

export { InputForm, InputErrorText };
export default Input;
