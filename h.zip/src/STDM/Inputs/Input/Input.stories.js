import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs, text, boolean } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import Input, { InputForm, InputErrorText } from "./Input";
import { ThemeProvider } from "styled-components";

const info = {
  info: {
    header: false,
    inline: true,
    text: `
    Это компонент Input.
    Простой компонент

    ~~~
    import { Input } from "heaven-components/dist/STDM";
    ~~~

    [Ссылка на дизайн](https://projects.invisionapp.com/d/main/default/#/console/13027675/283485250/preview)
  `
  }
};

storiesOf("Inputs|Input/[STDM]", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["Input"] })

  .add(
    "Стандартный вид",
    () => (
      <InputForm>
        <Input />
      </InputForm>
    ),
    info
  )
  .add(
    "On Hover",
    () => (
      <ThemeProvider
        theme={{
          Input: `
     border: 1px solid #788ece;
    color: #888e9f;
    `
        }}
      >
        <InputForm>
          <Input placeholder={"Введите текст"} />
        </InputForm>
      </ThemeProvider>
    ),
    info
  )
  .add(
    "On Focus",
    () => (
      <ThemeProvider
        theme={{
          Input: `
          border: 1px solid #b8c0d9;
    color: #000000;
    `
        }}
      >
        <InputForm>
          <Input placeholder={"Введите текст"} />
        </InputForm>
      </ThemeProvider>
    ),
    info
  )
  .add(
    "Error",
    () => (
      <ThemeProvider
        theme={{
          Input: `
          border: 1px solid #DE4D4D;
    `
        }}
      >
        <InputForm>
          <Input placeholder={"Введите текст"} />
        </InputForm>
      </ThemeProvider>
    ),
    info
  )
  .add(
    "Disabled",
    () => (
      <InputForm>
        <Input placeholder={"Введите текст"} disabled={true} />
      </InputForm>
    ),
    info
  )

  .add(
    "С параметрами",
    () => (
      <InputForm>
        <Input
          disabled={boolean("Disable", true, "params")}
          placeholder={"Введите текст"}
        />
        <InputErrorText>
          {text("Текст ошибки", "текст ошибки", "params")}
        </InputErrorText>
      </InputForm>
    ),
    info
  );
