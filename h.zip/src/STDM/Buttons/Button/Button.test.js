import React from "react";
import { configure, render, shallow, mount } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import Button from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";

describe("Button", () => {
  it("should render properly", () => {
    const component = shallow(<Button />);
    expect(toJson(component)).toBeDefined();
  });

  it("should match snapshot", () => {
    const component = render(<Button />);
    expect(toJson(component)).toMatchSnapshot();
  });

  it("on click", () => {
    let value = 1;
    const component = mount(
      <Button
        onClick={() => {
          value++;
        }}
      />
    );
    component.find("button").simulate("click");
    expect(value).toBe(2);
  });
});
