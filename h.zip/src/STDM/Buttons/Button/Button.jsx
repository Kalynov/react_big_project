import styled from "styled-components";

const generalStyle = `
  padding: 10px 15px;
  text-align: center;
  margin-bottom: 0;
  font-family: "ProximaNova-Regular";
  cursor: pointer;
  transition: 0.3s all;
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 100px;
  margin: 0; font-size: 100%; vertical-align: middle;
  outline: none !important;
  *overflow: visible; line-height: normal;
  cursor: pointer; -webkit-appearance: button;
  border: none;
  font-family: inherit;

  &:hover {
    background-color: #1f367d;
    color: #ffffff;
  }
  &:active {
    background-color: #051b5d;
    color: #ffffff;
    transform: scale(0.95);
  }
  &:disabled {
    color: white;
    background-color: #e0e4f1 !important;
    cursor: unset;
  }
`;

const Button = styled.button`
  ${generalStyle};

  background-color: #1f367d;
  color: #ffffff;
  ${props => props.theme.Button};
`;

export default Button;
