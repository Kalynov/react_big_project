import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import {
  withKnobs,
  color,
  text,
  number,
  boolean
} from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import centered from "@storybook/addon-centered";
import { ThemeProvider } from "styled-components";

import Button from "./Button";

storiesOf("Buttons|Button/[STDM]", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["Button"] })

  .add("Стандартный вид", () => <Button>{"Войти"}</Button>, {
    info: {
      inline: true,
      text: `


        ~~~
        import { Button } from "heaven-components/dist/STDM";
        ~~~

        [Ссылка на дизайн](https://projects.invisionapp.com/d/main/default/#/console/13027675/283485250/preview)

        - простой компонент
        - минимальная ширина: 150px
      `
    }
  })

  .add(
    "Большая кнопка",
    () => (
      <ThemeProvider
        theme={{
          Button: `
    background-color: ${color("Цвет", "#1f367d", "Параметры")};
    width: ${number(`Ширина`, 500, {}, `Параметры`)}px;
    height: ${number(`Высота`, 200, {}, `Параметры`)}px;

    `
        }}
      >
        <Button>{"Войти"}</Button>
      </ThemeProvider>
    ),
    {
      info: {
        inline: true,
        text: `


        ~~~
        import { Button } from "heaven-components/dist/STDM";
        ~~~

        [Ссылка на дизайн](https://projects.invisionapp.com/d/main/default/#/console/13027675/283485250/preview)

        - простой компонент
        - минимальная ширина: 150px
      `
      }
    }
  );
