import styled from "styled-components";

const FlexRowSpacer = styled.div`
  flex: 1 1 auto;
  align-self: auto;

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.FlexRowSpacer}
`;

/**
@component
*/
export default FlexRowSpacer;
