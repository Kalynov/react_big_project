import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import FlexRowSpacer from "./FlexRowSpacer";

const options = {
  info: {
    inline: true,
    text: `
    Это простой компонент FlexRowSpacer.

    Занимает свободное место в FlexRow.

    ~~~
    import { FlexRowSpacer } from "heaven-components/dist/STS";
    ~~~

    Дизайн, как и внешний вид, отсутствует.
  `
  }
};

storiesOf("Utils|FlexRowSpacer", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["FlexRowSpacer"] })

  .add("Стандартный вид", () => <span />, options);
