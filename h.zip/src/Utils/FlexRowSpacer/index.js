import FlexRowSpacer from "./FlexRowSpacer";

export default FlexRowSpacer;
