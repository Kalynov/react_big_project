import React from "react";
import { configure, render, shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
configure({ adapter: new Adapter() });
import FlexRow from "./index";
import "jest-styled-components";
import toJson from "enzyme-to-json";
import { ThemeProvider } from "styled-components";
import Theme from "./../../theme";

describe("FlexRow", () => {
  it("should render properly", () => {
    const component = render(
      <ThemeProvider theme={Theme}>
        <FlexRow />
      </ThemeProvider>
    );

    expect(component).toBeDefined();
  });

  it("should match snapshot", () => {
    const component = render(<FlexRow />);

    expect(toJson(component)).toMatchSnapshot();
  });
});
