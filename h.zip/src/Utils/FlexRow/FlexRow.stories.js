import React from "react";
import { storiesOf } from "@storybook/react";
import { withInfo } from "@storybook/addon-info";
import { withKnobs } from "@storybook/addon-knobs";
import { withSmartKnobs } from "storybook-addon-smart-knobs";
import { action } from "@storybook/addon-actions";
import FlexRow from "./FlexRow";
import FlexRowSpacer from "../FlexRowSpacer";
import styled from "styled-components";

const options = {
  info: {
    inline: false,
    text: `
    Это простой компонент FlexRow.

    Является оберткой над flex.

    ~~~
    import { FlexRow } from "heaven-components/dist/STS";
    ~~~

    Дизайн, как и внешний вид, отсутствует.
  `
  }
};

const Block = styled.div`
  background: gray;
  height: 100px;
  width: 100px;
  border: 1px solid black;
  margin: 3px;
`;

storiesOf("Utils|FlexRow", module)
  .addDecorator(withInfo)
  .addDecorator(withSmartKnobs)
  .addDecorator(withKnobs)
  .addParameters({ jest: ["FlexRow"] })

  .add(
    "Стандартный вид",
    () => (
      <FlexRow>
        <Block />
        <Block />
        <Block />
        <Block />
      </FlexRow>
    ),
    options
  )

  .add(
    "Использование с FlexRowSpacer",
    () => (
      <FlexRow>
        <Block />
        <Block />
        <FlexRowSpacer />
        <Block />
        <Block />
      </FlexRow>
    ),
    options
  );
