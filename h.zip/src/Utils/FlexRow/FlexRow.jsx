import React from "react";
import PropTypes from "prop-types";
import styled from "styled-components";

/**
 * Внутри styled-component'ов тема доступна как
 * props.theme, например, props.theme.primaryColor
 *
 * props.theme.FlexRow использовать не нужно,
 * это сделано только для кастомизации на стороне проекта
 */

const FlexRowContainer = styled.div`
  display: ${props => (props.inline ? "inline-flex" : "flex")};
  position: ${props => (props.relative ? "relative" : "static")};
  flex-direction: row;
  flex-wrap: ${props => (props.nowrap ? "nowrap" : "wrap")};
  justify-content: ${props =>
    props.spaceEvenly ? "space-evenly" : "space-between"};
  align-content: center;
  align-items: ${props =>
    props.stretch || props.stretchItems ? "stretch" : "center"};

  & > * {
    flex: ${props => (props.stretch ? 1 : 0)} 1 auto;
    align-self: auto;
  }

  height: ${props => (props.fullHeight ? "100%" : "auto")};

  ${/* istanbul ignore next */ props => props.theme.globalStyle}
  ${/* istanbul ignore next */ props => props.theme.FlexRow}
`;

class FlexRow extends React.PureComponent {
  static propTypes = {
    /** Отображать как строчный элемент */
    inline: PropTypes.bool,
    /** Расстояние вокруг элементами одинаковое */
    spaceEvenly: PropTypes.bool,
    /** Растягивать элементы и себя */
    stretch: PropTypes.bool,
    /** Растягивать элементы */
    stretchItems: PropTypes.bool,
    /** Запретить переносы */
    nowrap: PropTypes.bool,
    /** Занимать всю высоту */
    fullHeight: PropTypes.bool,
    /** Position relative */
    relative: PropTypes.bool
  };

  static defaultProps = {
    inline: false,
    spaceEvently: false,
    stretch: false,
    stretchItems: false,
    nowrap: false,
    fullHeight: false,
    relative: false
  };

  render() {
    return (
      <FlexRowContainer {...this.props}>{this.props.children}</FlexRowContainer>
    );
  }
}

export default FlexRow;
