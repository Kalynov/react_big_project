Служебные команды

```
npm run scripts
```

Запуск тестов по всем проектам

```
node runAllTests
```

Последовательность действий для CI

```
git pull

npm run test
node runAllTests

npm run build
npm run build-storybook
npm run npm:upload

git add package.json
git commit -a -m "Version increment"
git push
```