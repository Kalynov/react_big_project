const execa = require("execa");
const fs = require("fs");
const path = require("path");

(async () => {
  try {
    console.log("Удаляю node_modules");
    await execa("rm", ["-rf", "node_modules"]);
    console.log("Устанавливаю из стандартного package.json");
    await execa("npm", ["i"]);
    console.log("Запускаю тесты");
    await execa("npm", ["run", "test"]);
    console.log("Успешно");

    const files = await new Promise(resolve => {
      fs.readdir("./packageConfigs", (err, files) => resolve(files));
    });

    console.log();

    for (let key in files) {
      const file = files[key];

      console.log("Обрабатываю " + file);

      console.log("Удаляю node_modules");
      await execa("rm", ["-rf", "node_modules"]);
      console.log("Удаляю package.json");
      await execa("rm", ["-rf", "package.json"]);
      console.log("Удаляю package-lock.json");
      await execa("rm", ["-rf", "package-lock.json"]);

      console.log("Копирую package.json");
      await execa("cp", [
        path.resolve("./packageConfigs", file),
        "package.json"
      ]);
      console.log("Устанавливаю пакеты");
      await execa("npm", ["i"]);
      console.log("Устанавливаю нужные для тестов пакеты");
      await execa("npm", [
        "i",
        "jest-styled-components@^6.3.1",
        "enzyme-to-json@^3.3.4",
        "babel-plugin-styled-components@^1.8.0",
        "@babel/cli@^7.0.0",
        "@babel/core@^7.1.5",
        "@babel/plugin-proposal-class-properties@^7.1.0",
        "@babel/preset-env@^7.1.5",
        "@babel/preset-react@^7.0.0",
        "babel-core@^7.0.0-bridge.0",
        "babel-jest@^23.6.0",
        "babel-loader@^8.0.4",
        "babel-preset-env@^1.7.0",
        "enzyme@^3.7.0",
        "enzyme-adapter-react-16@^1.7.0",
        "jest@^23.6.0",
        "regenerator-runtime@^0.12.1",
        "react-chartjs-2@^2.7.4",
        "chart.js@^2.7.3",
        "babel-plugin-transform-amd-to-commonjs@^1.4.0"
      ]);
      console.log("Восстанавливаю package.json (для конфигов jest)");
      await execa("git", ["checkout", "package.json"]);
      console.log("Запускаю тесты");
      await execa("npm", ["run", "test"]);
      console.log("Успешно");

      console.log();
    }

    console.log("Восстанавливаю package.json");
    await execa("git", ["checkout", "package.json"]);
    console.log("Восстанавливаю package-lock.json");
    await execa("git", ["checkout", "package-lock.json"]);
    console.log("Устанавливаю из стандартного package.json");
    await execa("npm", ["i"]);

    console.log();
    console.log("Закончил");
  } catch (e) {
    console.log("Удаляю node_modules");
    await execa("rm", ["-rf", "node_modules"]);
    console.log("Восстанавливаю package.json");
    await execa("git", ["checkout", "package.json"]);
    console.log("Восстанавливаю package-lock.json");
    await execa("git", ["checkout", "package-lock.json"]);
    console.log("Устанавливаю из стандартного package.json");
    await execa("npm", ["i"]);

    console.log("Тесты запершились с ошибкой");
    console.error(e);
    process.exit(1);
  }
})();
